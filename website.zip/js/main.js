document.getElementById("one").innerHTML="Text One-- From Javascript",document.getElementById("two").innerHTML="Text two- From Javascript";
//# sourceMappingURL=main.js.map
